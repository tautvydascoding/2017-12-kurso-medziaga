<?php
/* Password reset process, updates database with new user password */